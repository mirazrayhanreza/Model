-- Database Schema for Modol Connect Backend (aaPanel / MySQL 8.0 / MariaDB)
-- Ready for direct phpMyAdmin / aaPanel Import without Permission Errors

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Admins Table
CREATE TABLE IF NOT EXISTS `admins` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(150) UNIQUE NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `role` VARCHAR(50) DEFAULT 'SUPER_ADMIN',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Cash Agents Table (Binance-Style B2B P2P Agent Profile)
CREATE TABLE IF NOT EXISTS `cash_agents` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `agent_code` VARCHAR(50) UNIQUE NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(30) UNIQUE NOT NULL,
    `email` VARCHAR(150) UNIQUE NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `country` VARCHAR(50) DEFAULT 'Bangladesh',
    `city` VARCHAR(100) DEFAULT 'Dhaka',
    `currency` VARCHAR(10) DEFAULT 'BDT',
    `buy_rate` DECIMAL(12,4) DEFAULT 122.5000,
    `sell_rate` DECIMAL(12,4) DEFAULT 120.8000,
    `min_limit` DECIMAL(12,2) DEFAULT 500.00,
    `max_limit` DECIMAL(12,2) DEFAULT 500000.00,
    `daily_limit` DECIMAL(12,2) DEFAULT 500000.00,
    `payment_methods` VARCHAR(255) DEFAULT 'bKash, Nagad, Rocket, Upay, Bank Transfer, Cash',
    `commission_rate` DECIMAL(5,2) DEFAULT 5.00,
    `wallet_balance` DECIMAL(12,2) DEFAULT 0.00,
    `available_balance` DECIMAL(12,2) DEFAULT 50000.00,
    `orders_count` INT DEFAULT 1250,
    `total_orders` INT DEFAULT 1250,
    `completion_rate` VARCHAR(20) DEFAULT '99.4%',
    `avg_release_time` VARCHAR(20) DEFAULT '2.4 min',
    `rating` DECIMAL(3,2) DEFAULT 4.95,
    `is_online` TINYINT(1) DEFAULT 1,
    `is_verified` TINYINT(1) DEFAULT 1,
    `status` ENUM('ACTIVE', 'SUSPENDED') DEFAULT 'ACTIVE',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.1 Countries Table (Binance-Style Dynamic Multi-Country Architecture)
CREATE TABLE IF NOT EXISTS `countries` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `country_name` VARCHAR(100) NOT NULL,
    `iso_code` VARCHAR(10) NOT NULL,
    `phone_code` VARCHAR(15) NOT NULL,
    `currency_code` VARCHAR(10) NOT NULL,
    `flag` VARCHAR(20) DEFAULT '🌐',
    `status` ENUM('Active', 'Inactive') DEFAULT 'Active',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.2 Payment Methods Table (Dynamic Country-linked Payment Methods)
CREATE TABLE IF NOT EXISTS `payment_methods` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `country_id` INT NOT NULL,
    `method_name` VARCHAR(100) NOT NULL,
    `method_type` ENUM('Mobile Wallet', 'Bank Transfer', 'Instant Bank', 'Cash', 'Card', 'E-Wallet', 'Crypto/USDT', 'Other') DEFAULT 'Mobile Wallet',
    `logo` VARCHAR(255) DEFAULT '',
    `min_amount` DECIMAL(12,2) DEFAULT 100.00,
    `max_amount` DECIMAL(12,2) DEFAULT 500000.00,
    `status` ENUM('Active', 'Inactive') DEFAULT 'Active',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`country_id`) REFERENCES `countries`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.3 Countries and Currencies Legacy Table
CREATE TABLE IF NOT EXISTS `countries_currencies` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `country_code` VARCHAR(10) NOT NULL,
    `country_name` VARCHAR(100) NOT NULL,
    `flag` VARCHAR(20) DEFAULT '🌐',
    `currency_code` VARCHAR(10) NOT NULL,
    `currency_symbol` VARCHAR(10) NOT NULL,
    `rate_to_usd` DECIMAL(12,4) NOT NULL DEFAULT 1.0000,
    `min_deposit` DECIMAL(12,2) DEFAULT 500.00,
    `min_withdrawal` DECIMAL(12,2) DEFAULT 1000.00,
    `status` ENUM('Active', 'Inactive') DEFAULT 'Active',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Users Table
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `uid` VARCHAR(64) UNIQUE,
    `name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(150) UNIQUE NOT NULL,
    `phone` VARCHAR(30) UNIQUE,
    `password` VARCHAR(255) DEFAULT '',
    `country` VARCHAR(50) DEFAULT 'Bangladesh',
    `city` VARCHAR(100) DEFAULT 'Dhaka',
    `role` VARCHAR(20) DEFAULT 'USER',
    `avatar_url` VARCHAR(255) DEFAULT NULL,
    `wallet_balance` DECIMAL(12,2) DEFAULT 0.00,
    `currency` VARCHAR(20) DEFAULT 'BDT (৳)',
    `kyc_status` ENUM('NONE', 'SUBMITTED', 'VERIFIED', 'REJECTED') DEFAULT 'NONE',
    `is_verified` TINYINT(1) DEFAULT 1,
    `status` ENUM('ACTIVE', 'SUSPENDED') DEFAULT 'ACTIVE',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Models Table
CREATE TABLE IF NOT EXISTS `models` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `uid` VARCHAR(64) UNIQUE,
    `user_id` INT NULL,
    `name` VARCHAR(100) NOT NULL,
    `hourly_rate` DECIMAL(10,2) NOT NULL DEFAULT 1500.00,
    `daily_rate` DECIMAL(10,2) DEFAULT 8000.00,
    `category` VARCHAR(50) NOT NULL DEFAULT 'Fashion',
    `location` VARCHAR(100) DEFAULT 'Dhaka',
    `is_online` TINYINT(1) DEFAULT 1,
    `is_verified` TINYINT(1) DEFAULT 1,
    `rating` DECIMAL(3,2) DEFAULT 4.90,
    `review_count` INT DEFAULT 0,
    `avatar_url` VARCHAR(255) DEFAULT NULL,
    `portfolio_images` TEXT NULL,
    `bio` TEXT NULL,
    `skills` VARCHAR(255) NULL,
    `languages` VARCHAR(255) NULL,
    `services` VARCHAR(255) NULL,
    `availability_days` VARCHAR(100) DEFAULT 'All Days',
    `gender` VARCHAR(20) DEFAULT 'Female',
    `age` INT DEFAULT 23,
    `height_cm` INT DEFAULT 172,
    `image_res_name` VARCHAR(100) DEFAULT 'model_ayesha',
    `country` VARCHAR(50) DEFAULT 'Bangladesh',
    `status` ENUM('AVAILABLE', 'BUSY', 'OFFLINE') DEFAULT 'AVAILABLE',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Bookings Table
CREATE TABLE IF NOT EXISTS `bookings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `booking_code` VARCHAR(50) NULL,
    `user_id` VARCHAR(50) NOT NULL,
    `model_id` INT NOT NULL,
    `model_name` VARCHAR(100) NOT NULL,
    `model_photo` VARCHAR(100) DEFAULT 'model_1',
    `date` VARCHAR(50) NOT NULL,
    `time` VARCHAR(50) NOT NULL,
    `service_type` VARCHAR(100) NOT NULL,
    `duration_hours` INT DEFAULT 2,
    `location` VARCHAR(150) NOT NULL,
    `notes` TEXT NULL,
    `total_price` DECIMAL(12,2) NOT NULL,
    `status` VARCHAR(50) DEFAULT 'PAYMENT_RECEIVED',
    `payment_status` VARCHAR(50) DEFAULT 'ESCROW_HELD',
    `payment_method` VARCHAR(50) DEFAULT 'WALLET',
    `model_earnings` DECIMAL(12,2) DEFAULT 0.00,
    `platform_fee` DECIMAL(12,2) DEFAULT 0.00,
    `proof_selfie_url` TEXT NULL,
    `proof_photos` TEXT NULL,
    `proof_gps_location` VARCHAR(100) NULL,
    `proof_notes` TEXT NULL,
    `proof_submitted_time` BIGINT NULL,
    `user_rating` INT DEFAULT 5,
    `user_feedback` TEXT NULL,
    `dispute_status` VARCHAR(50) NULL,
    `dispute_reason` TEXT NULL,
    `timestamp` BIGINT NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. B2B Escrow Orders Table
CREATE TABLE IF NOT EXISTS `b2b_orders` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_id` VARCHAR(50) UNIQUE NOT NULL,
    `user_id` VARCHAR(50) NOT NULL,
    `userName` VARCHAR(100) NOT NULL,
    `agent_id` VARCHAR(50) NOT NULL,
    `agent_name` VARCHAR(100) NOT NULL,
    `country` VARCHAR(50) DEFAULT 'Bangladesh',
    `type` VARCHAR(20) DEFAULT 'DEPOSIT',
    `amount` DECIMAL(12,2) NOT NULL,
    `currency` VARCHAR(10) DEFAULT 'BDT',
    `payment_method` VARCHAR(50) DEFAULT 'bKash',
    `agent_account_number` VARCHAR(50) NULL,
    `agent_account_holder` VARCHAR(100) NULL,
    `status` VARCHAR(50) DEFAULT 'PENDING_PAYMENT',
    `proof_screenshot_url` TEXT NULL,
    `transaction_ref` VARCHAR(100) NULL,
    `dispute_status` VARCHAR(50) NULL,
    `dispute_reason` TEXT NULL,
    `created_at` BIGINT NOT NULL DEFAULT 0,
    `updated_at` BIGINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Cash Collections Table
CREATE TABLE IF NOT EXISTS `cash_collections` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `collection_code` VARCHAR(30) UNIQUE NOT NULL,
    `booking_id` VARCHAR(30) NOT NULL,
    `agent_id` INT NOT NULL,
    `client_email` VARCHAR(150) NOT NULL,
    `amount` DECIMAL(12,2) NOT NULL,
    `status` ENUM('PENDING', 'PAID', 'REJECTED') DEFAULT 'PENDING',
    `receipt_photo_url` VARCHAR(255) NULL,
    `collected_at` TIMESTAMP NULL,
    `verified_by_admin` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Wallets & Withdraw Requests
CREATE TABLE IF NOT EXISTS `wallets` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_type` ENUM('ADMIN', 'MODEL', 'AGENT', 'USER') NOT NULL,
    `user_id` VARCHAR(50) NOT NULL,
    `balance` DECIMAL(12,2) DEFAULT 0.00,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `withdraw_requests` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_type` ENUM('MODEL', 'AGENT') NOT NULL,
    `user_id` VARCHAR(50) NOT NULL,
    `amount` DECIMAL(12,2) NOT NULL,
    `payment_method` VARCHAR(50) DEFAULT 'bKash Agent',
    `status` ENUM('PENDING', 'APPROVED', 'REJECTED') DEFAULT 'PENDING',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Notifications Table
CREATE TABLE IF NOT EXISTS `notifications` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(200) NOT NULL,
    `message` TEXT NOT NULL,
    `target` ENUM('ALL', 'USERS', 'MODELS', 'AGENTS') DEFAULT 'ALL',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. GPS Live Escort & Tracking Table
CREATE TABLE IF NOT EXISTS `gps_escort_sessions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `session_code` VARCHAR(50) UNIQUE NOT NULL,
    `booking_id` VARCHAR(50) NOT NULL,
    `model_id` INT DEFAULT NULL,
    `user_id` INT DEFAULT NULL,
    `model_lat` DECIMAL(10, 7) NOT NULL DEFAULT 23.7745000,
    `model_lng` DECIMAL(10, 7) NOT NULL DEFAULT 90.4120000,
    `user_lat` DECIMAL(10, 7) NOT NULL DEFAULT 23.7937000,
    `user_lng` DECIMAL(10, 7) NOT NULL DEFAULT 90.4066000,
    `distance_km` DECIMAL(6, 2) DEFAULT 2.40,
    `eta_minutes` INT DEFAULT 7,
    `speed_kmh` INT DEFAULT 28,
    `model_battery` INT DEFAULT 86,
    `user_battery` INT DEFAULT 92,
    `status` ENUM('EN_ROUTE', 'IN_TRANSIT', 'ARRIVED', 'COMPLETED', 'SOS_ALERT') DEFAULT 'EN_ROUTE',
    `transport_mode` VARCHAR(100) DEFAULT 'Car (Escort)',
    `sos_active` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `gps_escort_sessions` (`session_code`, `booking_id`, `model_lat`, `model_lng`, `user_lat`, `user_lng`, `distance_km`, `eta_minutes`, `speed_kmh`, `status`) VALUES
('TRK-84920', 'BK-1024', 23.7745000, 90.4120000, 23.7937000, 90.4066000, 2.40, 7, 28, 'EN_ROUTE'),
('TRK-77190', 'BK-2058', 23.8681000, 90.3984000, 23.8164000, 90.4074000, 5.80, 14, 35, 'IN_TRANSIT')
ON DUPLICATE KEY UPDATE `status` = VALUES(`status`);

-- 11. Default Seed Data
INSERT INTO `admins` (`id`, `name`, `email`, `password`, `role`) VALUES
(1, 'System Admin (Miraz Reza)', 'hmmirazreza2@gmail.com', 'Miraz@647291', 'SUPER_ADMIN'),
(2, 'System Admin', 'admin@modolconnect.com', 'admin123', 'SUPER_ADMIN')
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`), `password` = VALUES(`password`);

INSERT INTO `cash_agents` (`id`, `agent_code`, `name`, `phone`, `email`, `password`, `commission_rate`, `wallet_balance`, `status`) VALUES
(1, 'AGENT001', 'Agent Sumon', '+8801700000001', 'sumon@agent.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', 5.00, 12500.00, 'ACTIVE')
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

INSERT INTO `models` (`id`, `name`, `hourly_rate`, `category`, `location`, `rating`, `avatar_url`, `status`) VALUES
(1, 'Jessica Simpson', 2500.00, 'Fashion', 'Gulshan, Dhaka', 4.90, 'https://images.unsplash.com/photo-1534528741775-53994a69daeb', 'AVAILABLE'),
(2, 'Nusrat Jahan', 2000.00, 'Commercial', 'Banani, Dhaka', 4.85, 'https://images.unsplash.com/photo-1517841905240-472988babdf9', 'AVAILABLE'),
(3, 'Tania Hossain', 1800.00, 'Fitness', 'Dhanmondi, Dhaka', 4.75, 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1', 'AVAILABLE')
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

SET FOREIGN_KEY_CHECKS = 1;
